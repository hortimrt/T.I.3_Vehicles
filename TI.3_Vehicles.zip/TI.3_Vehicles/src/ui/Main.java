package ui;

import java.util.Scanner;

import model.ElectricCar;
import model.GasolineCar;
import model.HybridCar;
import model.Motorcycle;
import model.Seller;

public class Main {
	
	public static Scanner lt=new Scanner(System.in);
	public static Seller seller = new Seller("HM Autos");
	
	public void main(String[] args) {
		System.out.println("Choose an option: "+"\n"
				+ "1. Register a vehicle & calculate its selling price"+"\n"
				+ "2. Display the information of all of the vehicles of a category");
		int option=lt.nextInt();
        lt.nextLine();
        switch(option) {
		case 1:
			registerVehicle();
			break;
		case 2:
			vehiclesInfo();
			break;
		}
	}
	
	public static void registerVehicle(){
		System.out.println("Enter the id of the vehicle: ");
		String id=lt.nextLine();
		lt.nextLine();
		System.out.println("Enter its basic price: ");
		double basicPrice=lt.nextDouble();
		System.out.println("Enter its brand: ");
		String brand=lt.nextLine();
		System.out.println("Enter its model: ");
		String model=lt.nextLine();
		lt.nextLine();
		System.out.println("Enter its cylinder capacity: ");
		double cylinderCapacity=lt.nextDouble();
		System.out.println("Enter the distance travelled in kilometres: ");
		double kilometres=lt.nextDouble();
		System.out.println("Enter its license plate: ");
		String licensePlate=lt.nextLine();
		System.out.println("Is it used (yes or no) ?: ");
		String r=lt.nextLine();
		lt.nextLine();
		boolean used;
		if (r.equalsIgnoreCase("yes")) {
			used=true;
			}
		else {
			used=false;
			}
		System.out.println("Enter the price of its SOAT: ");
		double priceSoat=lt.nextDouble();
		System.out.println("Enter the year of its SOAT: ");
		int yearSoat=lt.nextInt();
		System.out.println("Enter the amount of coverage in case of accident (like written in the SOAT): ");
		double coverageAmount=lt.nextDouble();
		System.out.println("Enter the price of its certificateof techno-mechanical control: ");
		double priceTechControl=lt.nextDouble();
		System.out.println("Enter the year of its certificate of techno-mechanical control: ");
		int yearTechControl=lt.nextInt();
		System.out.println("Enter the gas levels (like written in the certificate): ");
		double gasLevels=lt.nextDouble();
		System.out.println("Enter the price of its owner's card: ");
		double priceOwnerCard=lt.nextDouble();
		System.out.println("Enter the year of its owner's card: ");
		int yearOwnerCard=lt.nextInt();
		System.out.println("Is it 1. a car 2. a motorcycle ?");
		int aux=lt.nextInt();
		if(aux==1) {
			System.out.println("Is it a 1. a sedan 2. a pickup truck ? ");
			int carT=lt.nextInt();
			System.out.println("How many doors does it have ?");
			int numDoors=lt.nextInt();
			System.out.println("Are the windows polarized ? (yes or no)");
			String pol=lt.nextLine();
			boolean polarizedWindows;
			if (pol.equalsIgnoreCase("yes")) {
				polarizedWindows=true;
				}
			else {
				polarizedWindows=false;
				}
			System.out.println("Is this car 1. with gasoline 2. hybrid 3. electric ?");
			int rep=lt.nextInt();
			if(rep==1) {
				System.out.println("Enter its tanker capacity (in galons): ");
				double tankerCapacity=lt.nextDouble();
				System.out.println("Is its gasoline 1. extra 2. regular 3. diesel ?");
				int gasolineT=lt.nextInt();
				double gasolineCons=tankerCapacity*(cylinderCapacity/150);
				
				System.out.println(seller.registerVehicle(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard, carT, numDoors, polarizedWindows, tankerCapacity, gasolineT, gasolineCons));
				GasolineCar g=new GasolineCar(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard, carT, numDoors, polarizedWindows, tankerCapacity, gasolineT, gasolineCons);
				g.sellingPrice(2022);
				}
			if(rep==2) {
				System.out.println("Enter its tanker capacity (in galons): ");
				double tankerCapacity=lt.nextDouble();
				System.out.println("Is its gasoline 1. extra 2. regular 3. diesel ?");
				int gasolineT=lt.nextInt();
				double gasolineCons=tankerCapacity*(cylinderCapacity/180);
				System.out.println("Is its charger 1. fast 2. normal ?");
				int chargerT=lt.nextInt();
				System.out.println("Enter the duration of its battery (per km): ");
				double batteryDuration=lt.nextDouble();
				double batteryCons=0;
				if(chargerT==1)
					batteryCons=batteryDuration*(cylinderCapacity/200);
				else
					batteryCons=(batteryDuration+7)*(cylinderCapacity/200);
				
				System.out.println(seller.registerVehicle(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard, carT, numDoors, polarizedWindows, tankerCapacity, gasolineT, gasolineCons, chargerT, batteryDuration, batteryCons));
				HybridCar h=new HybridCar(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard, carT, numDoors, polarizedWindows, tankerCapacity, gasolineT, gasolineCons, chargerT, batteryDuration, batteryCons);
				h.sellingPrice(2022);
				}
			if(rep==3) {
				System.out.println("Is its charger 1. fast 2. normal ?");
				int chargerT=lt.nextInt();
				System.out.println("Enter the duration of its battery (per km): ");
				double batteryDuration=lt.nextDouble();
				double batteryCons=0;
				if(chargerT==1)
					batteryCons=(batteryDuration+13)*(cylinderCapacity/100);
				else
					batteryCons=(batteryDuration+18)*(cylinderCapacity/100);
				
				System.out.println(seller.registerVehicle(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard, chargerT, batteryDuration, batteryCons));
				ElectricCar e=new ElectricCar(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate,used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard, carT, numDoors, polarizedWindows, chargerT, batteryDuration, batteryCons);
				e.sellingPrice(2022);
				}
			}
		if(aux==2) {
			System.out.println("Is it a 1. a standard moto 2. a sport moto 3. a scooter 4. a motorcross ? ");
			int motoT=lt.nextInt();
			System.out.println("Enter its tanker capacity (in galons): ");
			double tankerCapacity=lt.nextDouble();
			double gasolineCons=tankerCapacity*(cylinderCapacity/75);
			
			System.out.println(seller.registerVehicle(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard,  motoT, tankerCapacity, gasolineCons));
			Motorcycle m=new Motorcycle(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard, motoT, tankerCapacity, gasolineCons);
			m.sellingPrice(2022);
			}
		}
	
	public void vehiclesInfo() {
		System.out.println("Choose your sorting criteria :"+"\n"
				+ "1. type of vehicle"+"\n"
				+ "2. type of fuel"+"\n"
				+ "3. used/new");
		int option=lt.nextInt();
        lt.nextLine();
        switch(option) {
		case 1:
			seller.vehiclesInfoType();
			break;
		case 2:
			seller.vehiclesInfoFuel();
			break;
		case 3:
			seller.vehiclesInfoUsedNew();
			break;
	}
}
}
