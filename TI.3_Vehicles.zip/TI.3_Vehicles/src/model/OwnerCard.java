package model;

public class OwnerCard extends Document implements Decodable{

	public OwnerCard(double price, int year) {
		super(price, year);
	}

	@Override
	public double code() {
		return 0;
	}

}
