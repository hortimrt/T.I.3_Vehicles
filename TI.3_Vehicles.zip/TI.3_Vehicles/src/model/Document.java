package model;

public class Document {
	
	private double price;
	private static int year;
	
	public Document(double price,int year) {
		this.setPrice(price);
		this.setYear(year);
	}

	public static int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year= year;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
