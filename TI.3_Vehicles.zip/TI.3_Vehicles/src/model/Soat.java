package model;

public class Soat extends Document implements Decodable{
	
	private double coverageAmount;
	
	public Soat(double price, int year, double coverageAmount) {
		super(price, year);
		this.setCoverageAmount(coverageAmount);
	}

	@Override
	public double code() {
		return 0;
	}

	public double getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}
	

}
