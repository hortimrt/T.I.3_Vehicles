package model;

public interface Decodable {
	
	public double code();

}
