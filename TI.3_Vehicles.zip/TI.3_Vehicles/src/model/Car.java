package model;

public class Car extends Vehicle{

	private CarType carType;
	private int numdoors;
	private boolean polarizedWindows;
	
	public enum CarType{
		SEDAN,
		PICKUPTRUCK
	}
	
	public Car(String id, double basicPrice, String brand, String model, double cylinderCapacity, double kilometres, String licensePlate, boolean used, double priceSoat, int yearSoat, double coverageAmount, double priceTechControl, int yearTechControl, double gasLevels, double priceOwnerCard, int yearOwnerCard, int carT, int numdoors, boolean polarizedWindows) {
		super(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard);
		this.setNumdoors(numdoors);
		this.setPolarizedWindows(polarizedWindows);
		switch(carT) {
		case 1:
			this.setCarType(CarType.SEDAN);
			break;
		case 2:
			this.setCarType(CarType.PICKUPTRUCK);
			break;
		}
		
	}

	public CarType getCarType() {
		return carType;
	}

	public void setCarType(CarType carType) {
		this.carType = carType;
	}

	public int getNumdoors() {
		return numdoors;
	}

	public void setNumdoors(int numdoors) {
		this.numdoors = numdoors;
	}

	public boolean isPolarizedWindows() {
		return polarizedWindows;
	}

	public void setPolarizedWindows(boolean polarizedWindows) {
		this.polarizedWindows = polarizedWindows;
	}
	

}
