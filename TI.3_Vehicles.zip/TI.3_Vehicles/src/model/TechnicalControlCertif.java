package model;

public class TechnicalControlCertif extends Document implements Decodable{
	
	private double gasLevels;

	public TechnicalControlCertif(double price, int year, double gasLevels) {
		super(price, year);
		this.setGasLevels(gasLevels);
	}

	@Override
	public double code() {
		return 0;
	}

	public double getGasLevels() {
		return gasLevels;
	}

	public void setGasLevels(double gasLevels) {
		this.gasLevels = gasLevels;
	}

}
