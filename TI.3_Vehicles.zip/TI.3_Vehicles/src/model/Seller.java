package model;

import java.util.ArrayList;

public class Seller {
	
	private String name;
	private ArrayList<Vehicle> vehicles=new ArrayList<Vehicle>();
	
	public Seller(String name) {
		this.name=name;
		setVehicles(new ArrayList<Vehicle>());
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	
	public String registerVehicle(String id, double basicPrice, String brand, String model, double cylinderCapacity,double kilometres, String licensePlate, boolean used, double priceSoat, int yearSoat, double coverageAmount, double priceTechControl, int yearTechControl, double gasLevels, double priceOwnerCard, int yearOwnerCard, int carT, int numDoors, boolean polarizedWindows, double tankerCapacity,int gasolineT, double gasolineCons) {
		getVehicles().add(new GasolineCar(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard,  carT, numDoors, polarizedWindows, tankerCapacity, gasolineT, gasolineCons));
		String mess="A gasoline car was added.";
		return mess;
	
	}
	
	public String registerVehicle(String id, double basicPrice, String brand, String model, double cylinderCapacity,double kilometres, String licensePlate, boolean used, double priceSoat, int yearSoat, double coverageAmount, double priceTechControl, int yearTechControl, double gasLevels, double priceOwnerCard, int yearOwnerCard, int carT, int numDoors, boolean polarizedWindows, double tankerCapacity,int gasolineT, double gasolineCons, int chargerT, double batteryDuration, double batteryCons) {
		getVehicles().add(new HybridCar(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard,  carT, numDoors, polarizedWindows, tankerCapacity, gasolineT, gasolineCons, chargerT, batteryDuration, batteryCons));
		String mess="An hybrid car was added.";
		return mess;
	}
	
	public String registerVehicle(String id, double basicPrice, String brand, String model, double cylinderCapacity,double kilometres, String licensePlate, boolean used, double priceSoat, int yearSoat, double coverageAmount, double priceTechControl, int yearTechControl, double gasLevels, double priceOwnerCard, int yearOwnerCard,  int carT, int numDoors, boolean polarizedWindows, int chargerT, double batteryDuration, double batteryCons) {
		getVehicles().add(new ElectricCar(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate,used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard, carT, numDoors, polarizedWindows, chargerT, batteryDuration, batteryCons));
		String mess="An electric car was added.";
		return mess;
	}
	
	public String registerVehicle(String id, double basicPrice, String brand, String model, double cylinderCapacity,double kilometres, String licensePlate, boolean used, double priceSoat, int yearSoat, double coverageAmount, double priceTechControl, int yearTechControl, double gasLevels, double priceOwnerCard, int yearOwnerCard,  int motoT, double gasolineCapacity, double gasolineConsume) {
		getVehicles().add(new Motorcycle(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard, motoT, gasolineCapacity, gasolineConsume));
		String mess="A motorcycle was added.";
		return mess;
	}

	public String vehiclesInfoType() {
		ArrayList<String> gasolineCars=new ArrayList<String>();
		ArrayList<String> hybridCars=new ArrayList<String>();
		ArrayList<String> electricCars=new ArrayList<String>();
		ArrayList<String> motorcycles=new ArrayList<String>();
		for(int i=0; i<getVehicles().size(); i++) {
			if(getVehicles().get(i)!=null && getVehicles().get(i) instanceof GasolineCar) {
				gasolineCars.add(getVehicles().get(i).getClass().getDeclaredFields().toString());
			}
			if(getVehicles().get(i)!=null && getVehicles().get(i) instanceof HybridCar) {
				hybridCars.add(getVehicles().get(i).getClass().getDeclaredFields().toString());
			}
			if(getVehicles().get(i)!=null && getVehicles().get(i) instanceof ElectricCar) {
				electricCars.add(getVehicles().get(i).getClass().getDeclaredFields().toString());
			}
			if(getVehicles().get(i)!=null && getVehicles().get(i) instanceof Motorcycle) {
				motorcycles.add(getVehicles().get(i).getClass().getDeclaredFields().toString());
			}	
		}
		return "Here are all the informations about: \n"
				+ "the gasoline cars: "+gasolineCars+"\n"
				+ "the hybrid cars: "+hybridCars+"\n"
				+ "the electric cars: "+electricCars+"\n"
				+ "the motorcycles"+motorcycles;
	}

	public String vehiclesInfoFuel() {
		ArrayList<String> gasoline=new ArrayList<String>();
		ArrayList<String> electricity=new ArrayList<String>();
		for(int i=0; i<getVehicles().size(); i++) {
			if(getVehicles().get(i)!=null && getVehicles().get(i)instanceof GasolineCar || getVehicles().get(i)instanceof HybridCar || getVehicles().get(i)instanceof Motorcycle ) {
				gasoline.add(getVehicles().get(i).getClass().getDeclaredFields().toString());
			}
			else {
				electricity.add(getVehicles().get(i).getClass().getDeclaredFields().toString());
			}	
		}
		return "Here are all the informations about: \n"
		+ "the gasoline cars: "+gasoline+"\n"
		+ "the hybrid cars: "+electricity;	
	}

	public String vehiclesInfoUsedNew() {
		ArrayList<String> used=new ArrayList<String>();
		ArrayList<String> notUsed=new ArrayList<String>();
		for(int i=0; i<getVehicles().size(); i++) {
			if(getVehicles().get(i)!=null && getVehicles().get(i).isUsed()) {
				used.add(getVehicles().get(i).getClass().getDeclaredFields().toString());
			}
			else {
				notUsed.add(getVehicles().get(i).getClass().getDeclaredFields().toString());
			}
		}
		return "Here are all the informations about: \n"
		+ "the used cars: "+used+"\n"
		+ "the new cars: "+notUsed;
	}

	public ArrayList<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(ArrayList<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}
	
}
