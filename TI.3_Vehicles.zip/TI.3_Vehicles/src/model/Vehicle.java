package model;

public class Vehicle {
	
	private String id;
	private double basicPrice;
	private String brand;
	private String model;
	private double cylinderCapacity;
	private double kilometres;
	private String licensePlate;
	private boolean used;
	
	private Document documents[];
	
	public Vehicle(String id,double basicPrice, String brand, String model, double cylinderCapacity, double kilometres, String licensePlate, boolean used, double priceSoat, int yearSoat, double coverageAmount, double priceTechControl, int yearTechControl, double gasLevels, double priceOwnerCard, int yearOwnerCard) {
		this.id=id;
		this.basicPrice=basicPrice;
		this.setBrand(brand);
		this.setModel(model);
		this.setCylinderCapacity(cylinderCapacity);
		this.setKilometres(kilometres);
		this.setLicensePlate(licensePlate);
		this.used=used;
		documents=new Document[3];
		documents[0]=new Soat(priceSoat, yearSoat, coverageAmount);
		documents[1]=new TechnicalControlCertif(priceTechControl, yearTechControl, gasLevels);
		documents[2]=new OwnerCard(priceOwnerCard, yearOwnerCard);
	}

	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public double getBasicPrice() {
		return basicPrice;
	}

	public void setBasicPrice(double basicPrice) {
		this.basicPrice = basicPrice;
	}

	public boolean isUsed() {
		return used;
	}

	public void setUsed(boolean used) {
		this.used = used;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public double getCylinderCapacity() {
		return cylinderCapacity;
	}

	public void setCylinderCapacity(double cylinderCapacity) {
		this.cylinderCapacity = cylinderCapacity;
	}

	public double getKilometres() {
		return kilometres;
	}

	public void setKilometres(double kilometres) {
		this.kilometres = kilometres;
	}

	public String getLicensePlate() {
		return licensePlate;
	}

	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}
}
