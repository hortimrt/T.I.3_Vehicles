package model;

public class ElectricCar extends Car implements Sellable {
	
	private ChargerType chargerType;
	private double batteryDuration;
	private double batteryCons;
	
	public enum ChargerType{
		FAST,
		NORMAL
	}

	public ElectricCar(String id, double basicPrice, String brand, String model, double cylinderCapacity,double kilometres, String licensePlate, boolean used, double priceSoat, int yearSoat, double coverageAmount, double priceTechControl, int yearTechControl, double gasLevels, double priceOwnerCard, int yearOwnerCard, int carT, int numdoors, boolean polarizedWindows, int chargerT, double batteryDuration, double batteryCons) {
		super(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard, carT, numdoors, polarizedWindows);
		this.setBatteryDuration(batteryDuration);
		this.setBatteryCons(batteryCons);
		switch(chargerT) {
		case 1:
			this.setChargerType(ChargerType.FAST);
			break;
		case 2:
			this.setChargerType(ChargerType.NORMAL);
			break;
		}
		
	}

	@Override
	public double sellingPrice(int actualYear) {
		double sellingPrice=0;
		sellingPrice=getBasicPrice()*1.2;
		if(isUsed())
			sellingPrice=sellingPrice*0.9;
		return sellingPrice;
	}

	public ChargerType getChargerType() {
		return chargerType;
	}

	public void setChargerType(ChargerType chargerType) {
		this.chargerType = chargerType;
	}

	public double getBatteryDuration() {
		return batteryDuration;
	}

	public void setBatteryDuration(double batteryDuration) {
		this.batteryDuration = batteryDuration;
	}

	public double getBatteryCons() {
		return batteryCons;
	}

	public void setBatteryCons(double batteryCons) {
		this.batteryCons = batteryCons;
	}
	
}
