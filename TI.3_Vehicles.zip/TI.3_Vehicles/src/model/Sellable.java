package model;

public interface Sellable {
	
	public double sellingPrice(int actualYear);
	
}
