package model;

public class Motorcycle extends Vehicle implements Sellable {

	private MotorcyleType motorcyleType;
	private double gasolineCapacity;
	private double gasolineConsume;
	
	public enum MotorcyleType{
		STANDARD,
		SPORT,
		SCOOTER,
		MOTORCROSS	
	}
	
	public Motorcycle(String id, double basicPrice, String brand, String model, double cylinderCapacity,double kilometres, String licensePlate, boolean used, double priceSoat, int yearSoat, double coverageAmount, double priceTechControl, int yearTechControl, double gasLevels, double priceOwnerCard, int yearOwnerCard, int motoT, double gasolineCapacity, double gasolineConsume) {
		super(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard);
		this.setGasolineCapacity(gasolineCapacity);
		this.setGasolineConsume(gasolineConsume);
		switch(motoT) {
		case 1:
			this.setMotorcyleType(MotorcyleType.STANDARD);
			break;
		case 2:
			this.setMotorcyleType(MotorcyleType.SPORT);
			break;
		case 3:
			this.setMotorcyleType(MotorcyleType.SCOOTER);
			break;
		case 4:
			this.setMotorcyleType(MotorcyleType.MOTORCROSS);
			break;
		}
	}
	
	@Override
	public double sellingPrice(int actualYear) {
		double sellingPrice=0;
		sellingPrice=getBasicPrice()*1.04;
		if(isUsed())
			sellingPrice=sellingPrice*0.98;
		return sellingPrice;
	}

	public MotorcyleType getMotorcyleType() {
		return motorcyleType;
	}

	public void setMotorcyleType(MotorcyleType motorcyleType) {
		this.motorcyleType = motorcyleType;
	}

	public double getGasolineCapacity() {
		return gasolineCapacity;
	}

	public void setGasolineCapacity(double gasolineCapacity) {
		this.gasolineCapacity = gasolineCapacity;
	}

	public double getGasolineConsume() {
		return gasolineConsume;
	}

	public void setGasolineConsume(double gasolineConsume) {
		this.gasolineConsume = gasolineConsume;
	}
	

}
