package model;

public class GasolineCar extends Car implements Sellable{
	
	private double tankerCapacity;
	private GasolineType gasolineType;
	private double gasolineCons;
	
	public enum GasolineType{
		EXTRA,
		REGULAR,
		DIESEL
	}
	
	public GasolineCar(String id, double basicPrice, String brand, String model, double cylinderCapacity, double kilometres, String licensePlate, boolean used, double priceSoat, int yearSoat, double coverageAmount, double priceTechControl, int yearTechControl, double gasLevels, double priceOwnerCard, int yearOwnerCard, int carT, int numdoors, boolean polarizedWindows, double tankerCapacity,int gasolineT, double gasolineCons) {
		super(id, basicPrice, brand, model, cylinderCapacity, kilometres, licensePlate, used, priceSoat, yearSoat, coverageAmount, priceTechControl, yearTechControl, gasLevels, priceOwnerCard, yearOwnerCard, carT, numdoors, polarizedWindows);
		this.setTankerCapacity(tankerCapacity);
		this.setGasolineCons(gasolineCons);
		switch(gasolineT) {
		case 1:
			this.setGasolineType(GasolineType.EXTRA);
			break;
		case 2:
			this.setGasolineType(GasolineType.REGULAR);
			break;
		case 3:
			this.setGasolineType(GasolineType.DIESEL);
			break;
		}
	}

	@Override
	public double sellingPrice(int actualYear) {
		int yearSoat=Soat.getYear();
		int yearTechControl=TechnicalControlCertif.getYear();
		double sellingPrice=0;
		if(isUsed())
			sellingPrice=sellingPrice*0.9;
		if (yearSoat!=actualYear && yearTechControl!=actualYear)
			sellingPrice=getBasicPrice()+500000;
		return sellingPrice;
	}

	public double getTankerCapacity() {
		return tankerCapacity;
	}

	public void setTankerCapacity(double tankerCapacity) {
		this.tankerCapacity = tankerCapacity;
	}

	public GasolineType getGasolineType() {
		return gasolineType;
	}

	public void setGasolineType(GasolineType gasolineType) {
		this.gasolineType = gasolineType;
	}

	public double getGasolineCons() {
		return gasolineCons;
	}

	public void setGasolineCons(double gasolineCons) {
		this.gasolineCons = gasolineCons;
	}
}
